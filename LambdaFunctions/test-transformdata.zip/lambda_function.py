import boto3
import json

def lambda_handler(event, context):
    dynamodb = boto3.client('dynamodb')
    table_name = process.env.dynamoDB;
    
    response = dynamodb.scan(TableName=table_name)
    items = response['Items']
    
    for item in items:
        try:
            # Get the genre attribute value from the item
            genre_str = item.get('genre', {}).get('S', '')
            
            # Convert the genre string to a list containing only alphabets
            genre_list = json.loads(genre_str.replace("'", "\""))
            genre_list = [genre for genre in genre_list if isinstance(genre, str) and genre.isalpha()]
            
            if genre_list:
                # Update the genre attribute in the item
                dynamodb.update_item(
                    TableName=table_name,
                    Key={'uid': item['uid']},
                    UpdateExpression='SET #genre = :genre_val',
                    ExpressionAttributeNames={'#genre': 'genre'},
                    ExpressionAttributeValues={':genre_val': {'SS': genre_list}}
                )
            else:
                # Delete the erroneous row from the table if genre_list is empty
                dynamodb.delete_item(
                    TableName=table_name,
                    Key={'uid': item['uid']}
                )
        except Exception as e:
            print(f"Error processing item {item.get('uid', {}).get('S', '')}: {e}")
            # Delete the erroneous row from the table
            dynamodb.delete_item(
                TableName=table_name,
                Key={'uid': item.get('uid', {}).get('S', '')}
            )
    
    return {
        'statusCode': 200,
        'body': 'Genre attribute update completed.'
    }

