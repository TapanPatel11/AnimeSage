import boto3

# Initialize the DynamoDB client
dynamodb = boto3.client('dynamodb')

# Define the table name
table_name = process.env.dynamoDB

# Scan all items in the table
response = dynamodb.scan(TableName=table_name)

# Function to convert string to float (or int) safely
def safe_convert_to_number(value):
    try:
        return float(value)  # For floating-point numbers
        # return int(value)  # For integers
    except (ValueError, TypeError):
        return None

# List of fields to convert to numbers
fields_to_convert = ["episodes", "members", "popularity", "ranked", "score"]

# Loop through each item and update the specified attributes
for item in response['Items']:
    uid = item.get('uid', {}).get('S')
    
    # Loop through the fields and perform the conversion/update or deletion
    for field in fields_to_convert:
        attr = item.get(field, {})
        value = safe_convert_to_number(attr.get('S')) if 'S' in attr else None
        
        if uid and value is not None:
            try:
                # Update the item in the table with the new attribute value
                dynamodb.update_item(
                    TableName=table_name,
                    Key={'uid': {'S': uid}},
                    UpdateExpression=f'SET #{field} = :{field}',
                    ExpressionAttributeNames={f'#{field}': field},
                    ExpressionAttributeValues={f':{field}': {'N': str(value)}}
                )
            except Exception as e:
                print(f"Error updating row with uid '{uid}': {e}")
                # Delete the row if an error occurs during update
                dynamodb.delete_item(
                    TableName=table_name,
                    Key={'uid': {'S': uid}}
                )
        else:
            if not uid:
                print(f"Missing 'uid' attribute for row with field '{field}'. Skipping this item.")
            elif value is None:
                print(f"Invalid or missing '{field}' value for row with uid '{uid}'. Deleting the row.")
                # Delete the row if the conversion was not successful or the attribute is missing
                dynamodb.delete_item(
                    TableName=table_name,
                    Key={'uid': {'S': uid}}
                )

print("Conversion and cleanup complete.")

