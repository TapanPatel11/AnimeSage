import boto3
import json
import os


def lambda_handler(event, context):
    # Create an SQS client
    sqs = boto3.client('sqs')
    sns = boto3.client('sns')
    sns_topic_arn = os.environ['sns_topic_arn']
    queue_url = os.environ['queue_url']
    print(event)
    print('========================#####################')
    print(context)

    
    # Extract messages from the 'Records' field in the 'event'
    for record in event['Records']:
        message_body = json.loads(record['body'])
        sns_message = message_body['Message']
        print("Received message:", sns_message)

        subject = 'Anime Notification' 

        sns.publish(
            TopicArn=sns_topic_arn,
            Subject=subject,
            Message=sns_message
        )


        # Delete the processed message from the queue
        sqs.delete_message(
            QueueUrl=queue_url,
            ReceiptHandle=record['receiptHandle']
        )
        print('message delete from the queue')

    return {
        'statusCode': 200,
        'body': 'Messages extracted from SQS queue.'
    }

