import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const dynamo = DynamoDBDocumentClient.from(client);
const tableName = process.env.dynamoDB;

export const handler = async (event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json",
  };

  try {
    console.log("Received event:", JSON.stringify(event));

    switch (event.routeKey) {
      case "POST /filteranime":
        const requestBody = JSON.parse(event.body);
        const genres = requestBody.genres;
        const { episodes, score, popularity, ranked } = requestBody; // Destructure the properties

        if (!Array.isArray(genres) || genres.length === 0) {
          throw new Error("Invalid or empty genres array in the request.");
        }

        console.log("Genres:", genres);
        console.log("Episodes:", episodes);
        console.log("Score:", score);
        console.log("Popularity:", popularity);
        console.log("Ranked:", ranked);

        // Use the Scan operation to fetch items with matching genres and optional attributes
        let filterExpression = genres.map((genre, index) => `contains(#genre, :genreVal${index})`).join(" OR ");
        let expressionAttributeValues = genres.reduce((acc, genre, index) => {
          if (typeof genre === "string") {
            acc[`:genreVal${index}`] = { S: genre };
          }
          return acc;
        }, {});

        if (typeof episodes === "number") {
          filterExpression += " AND episodes >= :episodes";
          expressionAttributeValues[":episodes"] = { N: String(episodes) };
        }

        if (typeof score === "number") {
          filterExpression += " AND score >= :score";
          expressionAttributeValues[":score"] = { N: String(score) };
        }

        if (typeof popularity === "number") {
          filterExpression += " AND popularity >= :popularity";
          expressionAttributeValues[":popularity"] = { N: String(popularity) };
        }

        if (typeof ranked === "number") {
          filterExpression += " AND ranked >= :ranked";
          expressionAttributeValues[":ranked"] = { N: String(ranked) };
        }

        const scanParams = {
          TableName: tableName,
          FilterExpression: filterExpression,
          ExpressionAttributeNames: {
            "#genre": "genre",
          },
          ExpressionAttributeValues: expressionAttributeValues,
        };

        console.log("ScanParams:", scanParams);

        const result = await dynamo.send(new ScanCommand(scanParams));
        body = result.Items;

        break;

      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  } catch (err) {
    console.error("Error:", err);
    statusCode = 400;
    body = { message: err.message };
  } finally {
    // Convert body to JSON string only if it's an object
    if (typeof body === "object") {
      body = JSON.stringify(body);
    }

    console.log("Response body:", body);
  }

  return {
    statusCode,
    body,
    headers,
  };
};

