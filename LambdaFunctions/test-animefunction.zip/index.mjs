import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";
import { unmarshall } from "@aws-sdk/util-dynamodb";


let region = process.env.AWS_REGION
const client = new DynamoDBClient({});
const tableName = process.env.dynamoDB;

export const handler = async (event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json",
  };

  try {
    console.log("Received event:", JSON.stringify(event));

    switch (event.routeKey) {
      case "GET /genres":
        const scanParams = {
          TableName: tableName,
        };

        const data = await client.send(new ScanCommand(scanParams));

        // Extract unique genres from the returned data
        const genres = new Set();

        data.Items.forEach((item) => {
          if (item.genre) {
            if (item.genre.SS) {
              // Handle string set attribute
              item.genre.SS.forEach((genre) => {
                genres.add(genre);
              });
            } else if (Array.isArray(item.genre)) {
              // Handle array attribute
              item.genre.forEach((genre) => {
                genres.add(genre);
              });
            }
          }
        });

        // Convert the set of genres to an array
        const uniqueGenres = Array.from(genres);

        body = { genres: uniqueGenres };
        break;

      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  } catch (err) {
    console.error("Error:", err);
    statusCode = 400;
    body = { message: err.message };
  } finally {
    // Convert body to JSON string only if it's an object
    if (typeof body === "object") {
      body = JSON.stringify(body);
    }

    console.log("Response body:", body);
  }

  return {
    statusCode,
    body,
    headers,
  };
};

