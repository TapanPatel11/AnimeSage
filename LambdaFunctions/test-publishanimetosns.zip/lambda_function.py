import json
import boto3
import os

def lambda_handler(event, context):
    try:
        recommendation = json.loads(event['body'])

        message = f"Recommendation details via Email:\n" \
                  f"Title: {recommendation['title']}\n" \
                  f"Synopsis: {recommendation['synopsis']}\n" \
                  f"Episodes: {recommendation['episodes']}\n" \
                  f"Ranked: {recommendation['ranked']}\n" \
                  f"Popularity: {recommendation['popularity']}\n" \
                  f"Score: {recommendation['score']}\n" \
                  f"Genres: {', '.join(recommendation['genre'])}\n" \
                  f"Members: {recommendation['members']}\n" \
                  f"Image: {recommendation['img_url']}\n" \
                  f"Link: {recommendation['link']}\n" \
                  f"Aired: {recommendation['aired']}"

        sns_topic_arn = os.environ['sns_topic_arn']
        sns_client = boto3.client('sns')
        sns_client.publish(TopicArn=sns_topic_arn, Message=message)

        return {
            'statusCode': 200,
            'body': json.dumps('Recommendation details sent to SNS successfully.')
        }
    except Exception as e:
        error_message = 'Error processing the recommendation: ' + str(e)
        return {
            'statusCode': 500,
            'body': json.dumps('Error processing the recommendation. ' + error_message)
        }

